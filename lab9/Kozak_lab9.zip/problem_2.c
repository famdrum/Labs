#include <stdio.h>
#include <stdlib.h>

void print(){
	printf("Hello,world!");
}

int main(){
	print();
}